import SwiftUI
import AVFoundation
import UIKit

enum CalculatorOperation {
    case none, add, subtract, multiply, divide, squareRoot
}

struct Calculator: View {
    @State private var enteredNumber = ""
    @State private var currentOperation: CalculatorOperation = .none
    @State private var previousNumber = 0.0
    @State private var outputText = ""
    @State private var output = "0"
    @State private var previousResult: Double = 0.0
    @State private var lastEnteredNumber: Double = 0.0
    @State private var lastOperation: CalculatorOperation = .none
    @StateObject var player = MusicPlayer()
    @Binding var width_calc_button: CGFloat
    @Binding var height_calc_button: CGFloat
    @Binding var round_btn: CGFloat
    @Binding var selcolor: Color
    @Binding var selcolor2: Color
    @Binding var selcolor3: Color
    @Binding var font_size: CGFloat
    @Binding var font_size2: Int
    @Binding var width_calc_button2: Int
    @Binding var height_calc_button2: Int
    @Binding var shadow1: CGFloat
    @Binding var shadow1_2: Int
    @Binding var round_btn2: Int
    @Binding var shadow_opacity_1: CGFloat
    @Binding var shadow_opacity_1_2: Int
    @Binding var shadow_pos_x: CGFloat
    @Binding var shadow_pos_y: CGFloat
    @Binding var shadow_pos_x_p: Int
    @Binding var shadow_pos_y_p: Int
    @Binding var selcolor4: Color
    @Binding var grid_count: Int
    @Binding var symbols: [String]
    @Binding var width_border: CGFloat
    @Binding var send_var: Bool
    @Binding var color_border: Color
    @Binding var width_border1: Int
    @Binding var rotate_btn: CGFloat
    @Binding var rotate_btn1: Int
    @Binding var shadow2: CGFloat
    @Binding var hpt: UIImpactFeedbackGenerator.FeedbackStyle
    @Binding var sound: String
    @Binding var shadow2_2: Int
    @Binding var selcolor5: Color
    @Binding var setup: Bool
    @Binding var colorString: String
    @Binding var colorString2: String
    @Binding var colorString3: String
    @Binding var colorString4: String
    @Binding var colorString5: String
    @Binding var colorString6: String
    @Binding var round_btn12: CGFloat
    @Binding var round_btn12_2: Int
    @Binding var height_output_box: CGFloat
    @Binding var height_output_box2: Int
    @Binding var width_output_box: CGFloat
    @Binding var width_output_box2: Int
    @Binding var spacing_outputbox: CGFloat
    @Binding var spacing_outputbox_down: CGFloat
    @State private var testingshit: CGFloat = 1000
    @State private var started = true
    @Binding var spacing_grid_hor: CGFloat
    @Binding var spacing_grid_ver: CGFloat
    @Binding var spacing_outputbox_conv: Int
    @Binding var spacing_grid_hor_conv: Int
    @Binding var spacing_grid_ver_conv: Int
    @Binding var colorString7: String
    @Binding var uicolor: Color
    @Binding var fontName: String
    @Binding var selectedEmoji: String
    @AppStorage("used") var used: Bool = false
    @AppStorage("Update_fix0_5") var Update_fix0_5: Bool = true
    @State private var used2 = false
    @State private var offset: CGFloat = 0.0
    @State private var offset2: CGFloat = 0.0
    @State private var numblend: CGFloat = 1.0
    @State private var buttonScale: CGFloat = 1.0
    @Binding var gesturefield1: Int
    @Binding var gesturefield2: Int
    @Binding var gesturefield3: Int
    @Binding var gesture: Int
    @Binding var cph: [String]
    @Binding var font_size2_1: CGFloat
    @Binding var font_size2_2: Int
    @Binding var xemo: CGFloat
    @Binding var yemo: CGFloat
    @Binding var offsetx: Int
    @Binding var offsety: Int
    var body: some View {
        VStack {
            HStack {
                VStack(spacing: 0) {
                    Rectangle()
                        .frame(height: 3040)
                        .foregroundColor(selcolor3)
                    
                    VStack {
                        ZStack {
                            Rectangle()
                                .frame(width: width_output_box, height: height_output_box)
                                .cornerRadius(round_btn)
                                .foregroundColor(selcolor)
                                .shadow(color: selcolor4.opacity(shadow_opacity_1), radius: shadow1, x: shadow_pos_x, y: shadow_pos_y)
                            VStack {
                                Text(outputText)
                                    .font(.system(size: 35))
                                    .opacity(numblend)
                                    .foregroundColor(selcolor2)
                                    .frame(width: width_output_box-15, height: height_output_box-10)
                                    
                                    .shadow(color: selcolor5.opacity(shadow_opacity_1), radius: shadow2, x: 0, y: 0)
                            }
                            .frame(height: height_output_box)
                        }
                    }
                    .onTapGesture {
                        cph.append(enteredNumber)
                        UserDefaults.standard.set(cph, forKey: "cph")
                        UIPasteboard.general.string = enteredNumber
                                    
                                    // Optionally, you can show a success message using an alert
                                    let alert = UIAlertController(title: "Copied", message: "Text copied to clipboard", preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                    UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true, completion: nil)
                    }
                    .offset(x: offset, y: 0)
                                .gesture(
                                    DragGesture()
                                        .onChanged { gesture in
                                            if gesturefield1 > 0 {
                                                if gesture.translation.width < 0 {
                                                    self.offset = gesture.translation.width
                                                }
                                            }
                                            
                                            if gesturefield2 > 0 {
                                                if gesture.translation.width > 0 {
                                                    self.offset = gesture.translation.width
                                                }
                                            }
                                        }
                                        .onEnded { gesture in
                                            if gesturefield1 > 0 {
                                                if gesture.translation.width < -30 {
                                                    if gesturefield1 == 1 {
                                                        calcgestures()
                                                    } else if gesturefield1 == 2 {
                                                        calcgesture2()
                                                    }
                                                }
                                            }
                                            if gesturefield2 > 0 {
                                                if gesture.translation.width > 30 {
                                                    if gesturefield2 == 1 {
                                                        calcgestures()
                                                    } else if gesturefield2 == 2 {
                                                        calcgesture2()
                                                    }
                                                }
                                            }
                                            withAnimation {
                                                self.offset = 0
                                            }
                                            
                                        }
                                )
                             Rectangle()
                            .opacity(0)
                            .frame(height: spacing_outputbox)
                    VStack {
                        let columns: [GridItem] = Array(repeating: .init(.flexible()), count: grid_count)
                    
                        LazyVGrid(columns: columns, spacing: spacing_grid_hor) {
                            ForEach(symbols, id: \.self) { symbol in
                                Button(action: {
                                        buttonPressed(symbol)
                                        triggerHapticFeedback()
                                        if sound != "" {
                                            player.loadMusic(name: sound)
                                            player.play()
                                        }
                                }) { //design of a button
                                    ZStack {
                                        Rectangle()
                                            .frame(width: width_calc_button, height: height_calc_button)
                                            .cornerRadius(round_btn)
                                            .shadow(color: selcolor4.opacity(shadow_opacity_1), radius: shadow1, x: shadow_pos_x, y: shadow_pos_y)
                                            .foregroundColor(color_border)
                                            .rotationEffect(Angle(degrees: rotate_btn))
                                        
                                        Text("")
                                            .frame(width: width_calc_button - width_border, height: height_calc_button - width_border)
                                            .background(selcolor)
                                            .foregroundColor(selcolor2)
                                            .cornerRadius(round_btn)
                                            .rotationEffect(Angle(degrees: rotate_btn))
                                        Text(selectedEmoji)
                                            .font(.system(size: font_size2_1))
                                            .offset(x: xemo, y: yemo)
                                        Text(symbol)
                                            .foregroundColor(selcolor2)
                                            .font(.custom(fontName, size: font_size))
                                            .rotationEffect(Angle(degrees: rotate_btn + round_btn12))
                                            .shadow(color: selcolor5.opacity(shadow_opacity_1), radius: shadow2, x: 0, y: 0)
                                            .scaleEffect(buttonScale)
                                    }
                                }
                            }
                        }
                        .frame(width: spacing_grid_ver)
                        Rectangle()
                            .opacity(0)
                            .frame(height: 40)
                        }
                        .padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                        .padding(.horizontal)
                    Rectangle()
                        .frame(height: 3000)
                        .foregroundColor(selcolor3)
                        .overlay {
                            List {
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("tabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")
                                Text("TabViewBar")

                            }
                            .opacity(0)
                        }
                }
                .background(selcolor3)
                .frame(width: 3000, height: 3000) //width: 375
                .cornerRadius(round_btn)
                .edgesIgnoringSafeArea(.all)
            }
        }
            .onAppear {
                print(Update_fix0_5)
                print(used2)
                if Update_fix0_5 == true{
                    width_border = 10
                    width_calc_button = 50
                    height_calc_button = 50
                    selcolor = Color.gray
                    selcolor2 = Color.white
                    selcolor3 = Color.gray
                    selcolor4 = Color.black
                    selcolor5 = Color.black
                    color_border = Color.red
                    Update_fix0_5 = false
                    used2 = true
                }
                if used2 == true {
                    round_btn2 = Int(round_btn)
                    font_size2 = Int(font_size)
                    width_calc_button2 = Int(width_calc_button)
                    height_calc_button2 = Int(height_calc_button)
                    width_output_box2 = Int(width_output_box)
                    height_output_box2 = Int(height_output_box)
                    shadow1_2 = Int(shadow1)
                    shadow_opacity_1_2 = Int(shadow_opacity_1)
                    shadow_pos_x_p = Int(shadow_pos_x)
                    shadow_pos_y_p = Int(shadow_pos_y)
                    width_border1 = Int(width_border)
                    rotate_btn1 = Int(rotate_btn)
                    shadow2_2 = Int(shadow2)
                    round_btn12_2 = Int(round_btn12)
                    spacing_outputbox_conv = Int(spacing_outputbox)
                    spacing_grid_hor_conv = Int(spacing_grid_hor)
                    spacing_grid_ver_conv = Int(spacing_grid_ver)
                    font_size2_2 = Int(font_size2_1)
                    offsetx = Int(xemo)
                    offsety = Int(yemo)
                    convcolor()
                }
                let defaultSymbols = ["AC", "sin", "cos", "tan","√", "sin⁻¹", "cos⁻¹", "tan⁻¹","7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "-", "0", ".", "=", "+"]
                width_calc_button = CGFloat(width_calc_button2)
                height_calc_button = CGFloat(height_calc_button2)
                width_output_box = CGFloat(width_output_box2)
                height_output_box = CGFloat(height_output_box2)
                font_size = CGFloat(font_size2)
                round_btn = CGFloat(round_btn2)
                shadow1 = CGFloat(shadow1_2)
                shadow_opacity_1 = CGFloat(shadow_opacity_1_2)
                shadow_pos_x = CGFloat(shadow_pos_x_p)
                shadow_pos_y = CGFloat(shadow_pos_y_p)
                width_border = CGFloat(width_border1)
                rotate_btn = CGFloat(rotate_btn1)
                shadow2 = CGFloat(shadow2_2)
                round_btn12 = CGFloat(round_btn12_2)
                spacing_outputbox = CGFloat(spacing_outputbox_conv)
                spacing_grid_hor = CGFloat(spacing_grid_hor_conv)
                spacing_grid_ver = CGFloat(spacing_grid_ver_conv)
                font_size2_1 = CGFloat(font_size2_2)
                xemo = CGFloat(offsetx)
                yemo = CGFloat(offsety)
                used2 = true
                if used == false {
                    convcolor()
                    UserDefaults.standard.set(defaultSymbols, forKey: "Symbols")
                    used = true
                }
                cph = UserDefaults.standard.stringArray(forKey: "cph") ?? []
                symbols = UserDefaults.standard.stringArray(forKey: "Symbols") ?? []
                if started == false {
                    convcolor()
                } else if started == true {
                    convcolorback()
                }
        }
                }
    private func calcgestures() {
        if !enteredNumber.isEmpty {
            enteredNumber = String(enteredNumber.dropLast())
        }
        if enteredNumber.isEmpty {
            output = "0"
            outputText = "0"
        }
        if !enteredNumber.isEmpty {
            output = enteredNumber
            outputText = enteredNumber
        }
    }
    private func calcgesture2() {
        calculateResult()
        currentOperation = .none
    }
    private func colorToRGBString(_ color: Color) -> String {
        let uiColor = UIColor(color)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        let redInt = Int(red * 255)
        let greenInt = Int(green * 255)
        let blueInt = Int(blue * 255)
        
        return "\(redInt),\(greenInt),\(blueInt)"
    }

    private func RGBStringToColor(_ rgbString: String) -> Color {
        let components = rgbString.components(separatedBy: ",").compactMap { Int($0) }
        guard components.count == 3 else {
            return .black
        }
        
        let red = Double(components[0]) / 255.0
        let green = Double(components[1]) / 255.0
        let blue = Double(components[2]) / 255.0
        
        return Color(red: red, green: green, blue: blue)
    }
    private func convcolor() {
        colorString = colorToRGBString(selcolor)
        colorString2 = colorToRGBString(selcolor2)
        colorString3 = colorToRGBString(selcolor3)
        colorString4 = colorToRGBString(selcolor4)
        colorString5 = colorToRGBString(color_border)
        colorString6 = colorToRGBString(selcolor5)
        colorString7 = colorToRGBString(uicolor)
    }
    
    private func convcolorback() {
        selcolor = RGBStringToColor(colorString)
        selcolor2 = RGBStringToColor(colorString2)
        selcolor3 = RGBStringToColor(colorString3)
        selcolor4 = RGBStringToColor(colorString4)
        selcolor5 = RGBStringToColor(colorString6)
        color_border = RGBStringToColor(colorString5)
        uicolor = RGBStringToColor(colorString7)
    }
    
    private func buttonPressed(_ symbol: String) {
        switch symbol {
        case "0"..."9", ".":
            enteredNumber += symbol
            outputText = enteredNumber
        case "+", "-", "×", "÷":
            if outputText != "" {
                calculateResult()
            }
            enteredNumber = ""
            if let number = Double(outputText) {
                previousNumber = number
            }
            currentOperation = getOperationForSymbol(symbol)
        case "=":
            calculateResult()
            currentOperation = .none
        case "AC":
            enteredNumber = ""
            currentOperation = .none
            previousNumber = 0.0
            output = "0"
            outputText = "0"
            enteredNumber = ""
        case "ANS":
            enteredNumber = "\(previousResult)"
            outputText = enteredNumber
        case "sin":
            if let enteredNumberInDegrees = Double(enteredNumber) {
                let result = sin(enteredNumberInDegrees * Double.pi / 180.0)
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "cos":
            if let enteredNumberInDegrees = Double(enteredNumber) {
                let result = cos(enteredNumberInDegrees * Double.pi / 180.0)
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "tan":
            if let enteredNumberInDegrees = Double(enteredNumber) {    //sin⁻¹
                let result = tan(enteredNumberInDegrees * Double.pi / 180.0)
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "sin⁻¹":
            if let enteredNumberInDegrees = Double(enteredNumber) {
                let result = asin(enteredNumberInDegrees) * 180.0 / Double.pi
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "cos⁻¹":
            if let enteredNumberInDegrees = Double(enteredNumber) {
                let result = acos(enteredNumberInDegrees) * 180.0 / Double.pi
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "tan⁻¹":
            if let enteredNumberInDegrees = Double(enteredNumber) {    //sin⁻¹
                let result = atan(enteredNumberInDegrees) * 180.0 / Double.pi
                outputText = formatOutput(result) // Format the result
                enteredNumber = outputText
            } else {
                outputText = "Error: Invalid input"
            }
        case "π":
            enteredNumber = "\(Double.pi)"
            outputText = enteredNumber
        case "√":
                    if let enteredNumber = Double(enteredNumber) {
                        if enteredNumber >= 0 {
                            let result = sqrt(enteredNumber)
                            outputText = formatOutput(result) // Format the result
                        } else {
                            outputText = "Error: Invalid input"
                        }
                    }
        case "Rand":
                let randomNumber = Double.random(in: 0..<1)
                enteredNumber = "\(randomNumber)"
                outputText = enteredNumber
        case "%":
                if let number = Double(enteredNumber) {
                    let percentage = number / 100.0
                    enteredNumber = "\(percentage)"
                    outputText = enteredNumber
                }
        default:
            break
        }
        if let number = Double(enteredNumber), number > Double(Int.max) {
                outputText = "Error: Number too large"
            }
    }
    private func getOperationForSymbol(_ symbol: String) -> CalculatorOperation {
            switch symbol {
            case "+":
                return .add
            case "-":
                return .subtract
            case "×":
                return .multiply
            case "÷":
                return .divide
            case "√":
                return .squareRoot
            default:
                return .none
            }
        }
    private func performOperation(_ operation: CalculatorOperation) {
        if let number = Double(enteredNumber) {
            enteredNumber = ""
            currentOperation = operation
            previousNumber = number
        }
    }

    
    private func calculateResult() {
        if let number = Double(enteredNumber) {
            switch currentOperation {
            case .add:
                previousNumber += number
            case .subtract:
                previousNumber -= number
            case .multiply:
                previousNumber *= number
            case .divide:
                previousNumber /= number
            case .squareRoot:
                previousNumber = sqrt(number)
            case .none:
                previousNumber = number
            }
            
            let formattedResult = formatOutput(previousNumber)
            outputText = formattedResult
            enteredNumber = formattedResult
        }
    }
    private func formatOutput(_ number: Double) -> String {
        if number.isNaN || number.isInfinite {
            return "Error"
        }
        
        if floor(number) == number {
            return String(Int(number))
        }
        
        return String(format: "%.9g", number)
    }

    private func triggerHapticFeedback() {
            let generator = UIImpactFeedbackGenerator(style: hpt)
            generator.prepare()
            generator.impactOccurred()
        }
}

class MusicPlayer: NSObject, ObservableObject, AVAudioPlayerDelegate {
    private var player: AVAudioPlayer?
    
    @Published var isPlaying: Bool = false
    @Published var currentTime: String = "00:00"
    
    private func updateTime() {
        guard let player = player else { return }
        
        let minutes = Int(player.currentTime / 60)
        let seconds = Int(player.currentTime.truncatingRemainder(dividingBy: 60))
        
        currentTime = String(format: "%02d:%02d", minutes, seconds)
    }
    
    func loadMusic(name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: nil) else { return }
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.delegate = self
            player?.prepareToPlay()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func play() {
        guard let player = player else { return }
        
        if player.isPlaying {
            // Pause the current sound
            player.pause()
            isPlaying = false
        } else {
            // Play the new sound while keeping the previous sound playing
            player.play()
            isPlaying = true
        }
        
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            self.updateTime()
        }
    }
    
    func stop() {
        guard let player = player else { return }
        
        player.stop()
        player.currentTime = 0
        isPlaying = false
        currentTime = "00:00"
    }
}
